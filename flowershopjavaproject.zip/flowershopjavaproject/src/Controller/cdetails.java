/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.DBconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author CHAMI HANSIKA
 */
public class cdetails extends javax.swing.JFrame {

       Connection conn = null;
     preparedStatment Pst = null;
     ResultSet rs = null;
     
    public cdetails() {
        initComponents();
        conn = DBconnect.connect();
        tableload();
    }

    
    public void tabledata(){

       int r = Table2.getSelectedRow();
       
       String id = Table2.getValueAt(r, 0).toString();
       String name =Table2.getValueAt(r, 1).toString();
       String gender=Table2.getValueAt(r, 2).toString();
       String number =Table2.getValueAt(r, 3).toString();
       String address=Table2.getValueAt(r, 4).toString();
       
       cid.setText(id);
       cname.setText(name);
       cgender.setSelectedItem(gender);
       ccontact.setText(number);
       caddress.setText(address);
       
    }
    public void tableload(){
        try {
          String sql ="SELECT customerid,customername,gender,contactnumber,address FROM customerdetails";
          PreparedStatement pst = conn.prepareStatement(sql);
          
          rs = pst.executeQuery();
          Table2.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
          
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
     }
  }
    
// Declare the PreparedStatement variable as an instance variable in the inf.mainframe class
private PreparedStatement pst;

// Inside your update() method
public void update() {
    String id = cid.getText();
    String quantity = cname.getText();
    String type = (String) cgender.getSelectedItem(); // No need for toString() here
    String price = ccontact.getText();
    String pricel = caddress.getText();
    
  
    try {
        // Prepare the update SQL statement
        String sql = "UPDATE customerdetails SET customername=?, gender=?, contactnumber=?,address=? WHERE customerid=?";
        pst = conn.prepareStatement(sql);
        
        // Set the parameters for the PreparedStatement
        pst.setString(1, quantity);
        pst.setString(2, type);
        pst.setString(3, price);
        pst.setString(4, pricel);
        pst.setString(5, id);
        
        
        // Execute the update
        pst.executeUpdate(); // Use executeUpdate() for updates
        
        JOptionPane.showMessageDialog(null, "Update successful!");
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Update failed: " + e.getMessage());
        e.printStackTrace(); // Print stack trace for debugging
    }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cadress = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table2 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        cid = new javax.swing.JTextField();
        cname = new javax.swing.JTextField();
        ccontact = new javax.swing.JTextField();
        caddress = new javax.swing.JTextField();
        cgender = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        delete2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        cadress.setBackground(new java.awt.Color(255, 255, 255));
        cadress.setForeground(new java.awt.Color(0, 153, 153));
        cadress.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Customer Id");
        cadress.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, -1));

        jLabel2.setFont(new java.awt.Font("Algerian", 1, 36)); // NOI18N
        jLabel2.setText("CUSTOMER DETAILS");
        cadress.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Customer Name");
        cadress.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("Gender");
        cadress.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 260, -1, 20));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("Contact number");
        cadress.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 320, -1, -1));

        Table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Table2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Table2);

        cadress.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 200, 400, 160));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setText("Address");
        cadress.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, -1, -1));
        cadress.add(cid, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 140, 90, -1));

        cname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cnameActionPerformed(evt);
            }
        });
        cadress.add(cname, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 200, 90, -1));

        ccontact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ccontactActionPerformed(evt);
            }
        });
        cadress.add(ccontact, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 320, 90, -1));

        caddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                caddressActionPerformed(evt);
            }
        });
        cadress.add(caddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 380, 90, -1));

        cgender.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cgender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        cgender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cgenderActionPerformed(evt);
            }
        });
        cadress.add(cgender, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 250, -1, -1));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("GOTO HOME");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        cadress.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 490, -1, -1));

        delete2.setBackground(new java.awt.Color(255, 255, 255));
        delete2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        delete2.setText("Delete");
        delete2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete2ActionPerformed(evt);
            }
        });
        cadress.add(delete2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 490, -1, -1));

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton3.setText("Submit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        cadress.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 490, -1, -1));

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setText("Update");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        cadress.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 490, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/potos/OIP.jpg"))); // NOI18N
        jLabel7.setText("jLabel7");
        cadress.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, 480, 490));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cadress, javax.swing.GroupLayout.DEFAULT_SIZE, 827, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cadress, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cnameActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

int id;
String name;
String gender;
int number;
String address;

try {
    id = Integer.parseInt(cid.getText());
    name = cname.getText(); // Assuming it's a text field, not a method getName()
    gender = cgender.getSelectedItem().toString();
    number = Integer.parseInt(ccontact.getText()); // Assuming it's a text field, not a method getName()
    address = caddress.getText();

    String sql = "INSERT INTO  customerdetails(customerid,customername,gender,contactnumber,address) VALUES (?, ?, ?, ?, ?)";
    PreparedStatement pst = conn.prepareStatement(sql);

    pst.setInt(1, id);
    pst.setString(2, name);
    pst.setString(3, gender);
    pst.setInt(4, number);
    pst.setString(5, address);
   

    pst.executeUpdate();
    
    JOptionPane.showMessageDialog(null, "Record inserted successfully");

} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(null, "Invalid input format: " + e.getMessage());
} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
}

tableload();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void cgenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cgenderActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cgenderActionPerformed

    private void ccontactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ccontactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ccontactActionPerformed

    private void caddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_caddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_caddressActionPerformed

    private void Table2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table2MouseClicked
tabledata();        
    }//GEN-LAST:event_Table2MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
update();  
tableload();

    }//GEN-LAST:event_jButton4ActionPerformed

    private void delete2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete2ActionPerformed
int check = JOptionPane.showConfirmDialog(null, "Do you want to delete?");

    if (check == 0) {
        String customerid= cid.getText();
        try {
            String sql = "DELETE FROM  customerdetails WHERE customerid=?" ;
            pst = conn.prepareStatement(sql);
            pst.setString(1, customerid);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Deleted");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Delete failed: " + e.getMessage());
        } finally {
            try {
                if (pst != null) pst.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
   tableload();
         
    }//GEN-LAST:event_delete2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       login bh = new login();
       bh.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(cdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(cdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(cdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(cdetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new cdetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Table2;
    private javax.swing.JTextField caddress;
    private javax.swing.JPanel cadress;
    private javax.swing.JTextField ccontact;
    private javax.swing.JComboBox<String> cgender;
    private javax.swing.JTextField cid;
    private javax.swing.JTextField cname;
    private javax.swing.JButton delete2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
