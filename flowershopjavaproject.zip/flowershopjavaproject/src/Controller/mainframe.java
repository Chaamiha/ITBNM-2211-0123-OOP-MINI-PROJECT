
package Controller;


import Model.DBconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

public class mainframe extends javax.swing.JFrame {
     
    Connection conn = null;
     preparedStatment Pst = null;
     ResultSet rs = null;
     
   
      
    public mainframe() {
     initComponents();
     conn = DBconnect.connect();
     
    tableload();
     
        
    }
    
    public void tabledata(){

       int r = table1.getSelectedRow();
       
       String id = table1.getValueAt(r, 0).toString();
       String name = table1.getValueAt(r, 1).toString();
       String typ = table1.getValueAt(r, 2).toString();
       String add = table1.getValueAt(r, 3).toString();
       
       fid.setText(id);
       fquantity.setText(name);
       ftype.setSelectedItem(typ);
       fprice.setText(add);
       
       
   
    }
    
  
    
    
    public void tableload(){
        try {
          String sql ="SELECT flowerid,quantity,type,price FROM flowerdetails";
          PreparedStatement pst = conn.prepareStatement(sql);
          
          rs = pst.executeQuery();
          table1.setModel(DbUtils.resultSetToTableModel(rs));
          
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
// Declare the PreparedStatement variable as an instance variable in the inf.mainframe class
private PreparedStatement pst;

// Inside your update() method
// Declare the PreparedStatement variable as an instance variable in the inf.mainframe class

// Inside your update() method
public void update() {
    String id = fid.getText();
    String quantity = fquantity.getText();
    String type = (String) ftype.getSelectedItem(); // No need for toString() here
    String price = fprice.getText();
  
    try {
        // Prepare the update SQL statement
        String sql = "UPDATE flowerdetails SET quantity=?, type=?, price=? WHERE flowerid=?";
        pst = conn.prepareStatement(sql);
        
        // Set the parameters for the PreparedStatement
        pst.setString(1, quantity);
        pst.setString(2, type);
        pst.setString(3, price);
        pst.setString(4, id);
        
        // Execute the update
        pst.executeUpdate(); // Use executeUpdate() for updates
        
        JOptionPane.showMessageDialog(null, "Update successful!");
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Update failed: " + e.getMessage());
        e.printStackTrace(); // Print stack trace for debugging
    }
}



  
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        finsert = new javax.swing.JButton();
        fid = new javax.swing.JTextField();
        ftype = new javax.swing.JComboBox<>();
        fquantity = new javax.swing.JTextField();
        fprice = new javax.swing.JTextField();
        fdelete = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        fupdate = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        fback = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 72, -1, -1));

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(255, 204, 204));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("Flower id");
        jPanel5.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel5.setText("Type");
        jPanel5.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel6.setText("quantity");
        jPanel5.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel7.setText("price");
        jPanel5.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, -1));

        finsert.setBackground(new java.awt.Color(255, 255, 255));
        finsert.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        finsert.setText("Insert");
        finsert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finsertActionPerformed(evt);
            }
        });
        jPanel5.add(finsert, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, -1, -1));

        fid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        fid.setCaretColor(new java.awt.Color(0, 51, 51));
        fid.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        fid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fidActionPerformed(evt);
            }
        });
        jPanel5.add(fid, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 190, 30));

        ftype.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ftype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Rose", "Tulip", "Anthurium", "Lotus", "Lavender", "Sunflower", "Orchied" }));
        ftype.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftypeActionPerformed(evt);
            }
        });
        jPanel5.add(ftype, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 270, 110, 30));

        fquantity.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel5.add(fquantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 190, 30));

        fprice.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPanel5.add(fprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 340, 200, 30));

        fdelete.setBackground(new java.awt.Color(255, 255, 255));
        fdelete.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fdelete.setText("Delete");
        fdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fdeleteActionPerformed(evt);
            }
        });
        jPanel5.add(fdelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 430, -1, -1));

        jLabel2.setFont(new java.awt.Font("Harrington", 1, 36)); // NOI18N
        jLabel2.setText("Flower DETAIL");
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\CHAMI HANSIKA\\Documents\\NetBeansProjects\\JavaApplication2\\src\\potos\\OIP.jpg")); // NOI18N
        jLabel8.setText("jLabel8");
        jPanel5.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(-90, -100, 500, 660));

        jPanel4.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 360, 470));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fupdate.setBackground(new java.awt.Color(255, 255, 255));
        fupdate.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fupdate.setText("update");
        fupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fupdateActionPerformed(evt);
            }
        });
        jPanel2.add(fupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 430, -1, -1));

        table1.setFont(new java.awt.Font("Sylfaen", 0, 14)); // NOI18N
        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "FlowerId", "Type", "Quantity", "Price"
            }
        ));
        table1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table1);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 430, 160));

        fback.setBackground(new java.awt.Color(255, 255, 255));
        fback.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        fback.setText("Next");
        fback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fbackActionPerformed(evt);
            }
        });
        jPanel2.add(fback, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 430, 80, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\CHAMI HANSIKA\\Documents\\NetBeansProjects\\JavaApplication2\\src\\potos\\OIP.jpg")); // NOI18N
        jLabel4.setText("jLabel4");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, -130, 1040, 720));

        jPanel4.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 450, 470));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fdeleteActionPerformed
                                      
    int check = JOptionPane.showConfirmDialog(null, "Do you want to delete?");

    if (check == 0) {
        String flowerid = fid.getText();
        try {
            String sql = "DELETE FROM  flowerdetails WHERE flowerid=?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, flowerid);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Deleted");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Delete failed: " + e.getMessage());
        } finally {
            try {
                if (pst != null) pst.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    tableload();
    
    }//GEN-LAST:event_fdeleteActionPerformed

    private void fidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fidActionPerformed

    private void ftypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ftypeActionPerformed

    private void finsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finsertActionPerformed
    
                                            
int id;
int quantity;
String type;
int price;

try {
    id = Integer.parseInt(fid.getText());
    quantity = Integer.parseInt(fquantity.getText()); // Assuming it's a text field, not a method getName()
    type = ftype.getSelectedItem().toString();
    price = Integer.parseInt(fprice.getText()); // Assuming it's a text field, not a method getName()
  

    String sql = "INSERT INTO  flowerdetails (flowerid,quantity,type,price) VALUES (?, ?, ?, ?)";
    PreparedStatement pst = conn.prepareStatement(sql);

    pst.setInt(1, id);
    pst.setInt(2, quantity);
    pst.setString(3, type);
    pst.setInt(4, price);
   

    pst.executeUpdate();
    
    JOptionPane.showMessageDialog(null, "Record inserted successfully");

} catch (NumberFormatException e) {
    JOptionPane.showMessageDialog(null, "Invalid input format: " + e.getMessage());
} catch (SQLException e) {
    JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
}
tableload();

    }//GEN-LAST:event_finsertActionPerformed

    private void fbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fbackActionPerformed
cdetails ch = new cdetails();
ch.setVisible(true);
this.dispose();

    }//GEN-LAST:event_fbackActionPerformed

    private void fupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fupdateActionPerformed
          update();  
          tableload();
          
    }//GEN-LAST:event_fupdateActionPerformed

    private void table1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table1MouseClicked
       tabledata();
    }//GEN-LAST:event_table1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mainframe().setVisible(true);
            }
        });
    }
    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton fback;
    private javax.swing.JButton fdelete;
    private javax.swing.JTextField fid;
    private javax.swing.JButton finsert;
    private javax.swing.JTextField fprice;
    private javax.swing.JTextField fquantity;
    private javax.swing.JComboBox<String> ftype;
    private javax.swing.JButton fupdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table1;
    // End of variables declaration//GEN-END:variables

    private cdetails cdetails() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
