
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DBconnect {
    // Method to establish database connection
    public static Connection connect() {
        Connection conn = null;
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Database connection parameters
            String url = "jdbc:mysql://localhost:3306/flowershop1";
            String username = "root";
            String password = "";  // Put your MySQL password here
            
            // Establish the connection
            conn = DriverManager.getConnection(url, username, password);
            
            // Optionally, you can print a message to confirm successful connection
            System.out.println("Connected to the database.");
        } catch (ClassNotFoundException | SQLException e) {
            // Handle any exceptions
            JOptionPane.showMessageDialog(null, "Failed to connect to the database: " + e.getMessage());
            e.printStackTrace(); // Print the stack trace for debugging
        }
        return conn;
    }
}


